package service;

import java.util.List;

import entities.user.UserMaster;

public interface UserService {

	//
	public UserMaster saveUser(UserMaster usMaster);
	

	// get all user
	public List<UserMaster> getAllUser();
	
	// get single user
	
	public UserMaster getUserById(String user_id);
	
	public void deleteUserById(String user_id);
	
	
	
	
	
	
}
