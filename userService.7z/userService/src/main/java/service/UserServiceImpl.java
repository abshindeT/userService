package service;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import entities.user.UserMaster;
import exceptions.ResourceNotFoundException;
import repositories.UserRepository;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserRepository userRepository;

	@Override
	public UserMaster saveUser(UserMaster usMaster) {
		// TODO Auto-generated method stub
		String randomUserId = UUID.randomUUID().toString();
		usMaster.setUserId(randomUserId);
		return userRepository.save(usMaster);
	}

	@Override
	public List<UserMaster> getAllUser() {
		// TODO Auto-generated method stub
		return userRepository.findAll();
	}

	@Override
	public UserMaster getUserById(String user_id) {
		// TODO Auto-generated method stub
		return userRepository.findById(user_id).orElseThrow
				(()->new ResourceNotFoundException("user with given id not found on server") );
	}

	@Override
	public void deleteUserById(String user_id) {
    userRepository.deleteById(user_id);;		
	}

}
