package repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.support.JpaEntityInformation;
import org.springframework.data.jpa.repository.support.SimpleJpaRepository;
import org.springframework.stereotype.Repository;

import entities.user.UserMaster;
import jakarta.persistence.EntityManager;

@Repository
public interface UserRepository extends JpaRepository<UserMaster, String>{

	

}
