package entities.user;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name="micro_users")
public class UserMaster {
	
	public UserMaster() {
		
	}
	
	public UserMaster(String userId, String userName, String email, String status) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.email = email;
		this.status = status;
	}

	@Id
	@Column(name="userId")
	private String userId;
	
	@Column(name="user_name")
	private String userName;
	
	@Column(name="email")
	private String email;
	
	@Column(name="status")
	private String status;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	public static class Builder {
        private String userId;
        private String userName;
        private String email;
        private String status;
        
        public Builder userId(String userId) {
            this.userId = userId;
            return this;
        }
        
        public Builder userName(String userName) {
            this.userName = userName;
            return this;
        }
        
        public Builder email(String email) {
            this.email = email;
            return this;
        }
        
        public Builder status(String status) {
            this.status = status;
            return this;
        }
        
        public UserMaster build() {
            return new UserMaster(userId, userName, email, status);
        }
    }

}
